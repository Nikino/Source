package com.example.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

class OverlayService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        FrameLayout container = new FrameLayout(this);
        View circleView = new View(this);
        circleView.setLayoutParams(new FrameLayout.LayoutParams(400, 400));

        ShapeDrawable drawable = new ShapeDrawable(new OvalShape());
        drawable.getPaint().setColor(Color.WHITE);
        drawable.getPaint().setAlpha(150);
        drawable.getPaint().setStyle(android.graphics.Paint.Style.STROKE);
        drawable.getPaint().setStrokeWidth(10);
        circleView.setBackground(drawable);

        container.addView(circleView);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;

        wm.addView(container, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
